// A) public interface Calendar
// B) public class Calendar
// C) public class interface Calendar
public interface Calendar {
    int DAYS_OF_THE_WEEK = 7;
}