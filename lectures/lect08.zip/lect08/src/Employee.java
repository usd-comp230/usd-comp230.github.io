public class Employee {
    public String name;
    public double salary;

    public Employee(String name) {
        name = name;
    }

    public static void main(String[] args) {
//        Employee e;
//        System.out.print(e.name);
//
//        Employee e = new Employee();
//        System.out.print(e.name);

        Employee e = new Employee("Sophia");
        System.out.print(e.name);


    }
}



