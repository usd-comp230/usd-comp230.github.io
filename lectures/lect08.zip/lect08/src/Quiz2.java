import java.util.ArrayList;
import java.util.List;

public class Quiz2 {
    public static void main(String[] args) {
        // A) Instance
        // B) static


        List<String> myList = new ArrayList<String>();

        // A) Yes
        // B) No
        int[] arr = {1, 2, 3};
        System.out.print(arr[2]);

        // A) Yes
        // B) No
        for (int i = 0; i <= arr.length; i++) {
            System.out.println(arr[i]);
        }
    }
}
